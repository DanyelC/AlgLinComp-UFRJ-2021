package telas;
import  mat.MatFunc;
import mat.Resposta;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.AbstractButton;
import javax.swing.DropMode;
import javax.swing.ButtonGroup;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import java.awt.Rectangle;

public class Tela_integral extends JFrame {
	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela_integral frame = new Tela_integral();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void calc(String caminhosaida , String intervalo_string, String n_string, String metodo) throws Exception {
		int n=0;
		double [] pontos = new double[3];
		try{
			n = Integer.parseInt(n_string);
			if(n<2 || n>10) {
				JOptionPane.showMessageDialog(null,"ERRO! - Escreva um valor inteiro de 2 a 10 para o n�mero de pontos.");
				return;
			}
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null,"ERRO! - A entrada 'n�mero de pontos' deve ser um n�mero inteiro.");
			return;
		}
		
		String[] parts = intervalo_string.split(",");
		for(int i = 0; i < 2; i++ ) {
			pontos[i]=Double.parseDouble(parts[i]);
			//System.out.printf("%.2f ", pontos[i]);
		}


		FileWriter arquivo_saida = new FileWriter(caminhosaida);
		PrintWriter escritor = new PrintWriter(arquivo_saida);

		escritor.print("Intervalo lido [a, b] : ");
		escritor.printf("(%.2f, %.2f)", pontos[0],pontos[1]);
		escritor.println();
		escritor.print("N�mero de pontos escolhidos entre 1 e 10 : ");
		escritor.printf("%d", n);
		escritor.println();

		//escritor.close(); 

		double[] consts = Tela_principal.constantes();

		switch (metodo) {
		case "quadgauss": 
			double resp = MatFunc.quad_gauss(consts, pontos, n); // VER ISSO
			escritor.println("Usando a quadratura de Gauss");
			escritor.printf("Valor encontrado: %.3f", resp);
			arquivo_saida.close();
			JOptionPane.showMessageDialog(null,"Arquivo gerado com sucesso em: "+caminhosaida);
			break;


		case "quadpoli": 
			double resp1 =MatFunc.quad_poli(consts, pontos, n);  //VER ISSO!!!!!!!!!!!!!!!!!!!!!!!!!
			escritor.println("Usando a quadratura polinomial");
			escritor.printf("Valor encontrado: %.3f", resp1);
			arquivo_saida.close();
			JOptionPane.showMessageDialog(null,"Arquivo gerado com sucesso em: "+caminhosaida);
			break;
		}
	}


	/**
	 * Create the frame.
	 */
	public Tela_integral() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Tela_integral.class.getResource("/imagens/logo1.jpg")));
		setTitle("C\u00E1lculo de integrais");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 722, 255); // tamanho da tela

		JFileChooser openFileChooser;
		openFileChooser = new JFileChooser();
		openFileChooser.setCurrentDirectory(new File ("c:\\temp"));
		openFileChooser.setFileFilter(new FileNameExtensionFilter("arquivos em texto","txt"));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.LIGHT_GRAY);
		contentPane.add(tabbedPane, BorderLayout.CENTER);


		ActionListener iterativoActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener decActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};


		JPanel panel = new JPanel();
		panel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		panel.setBackground(Color.LIGHT_GRAY);
		tabbedPane.addTab("Dados de Entrada", null, panel, null);

		JLabel lblOrdemDaMatriz = new JLabel("Intervalo a,b");
		lblOrdemDaMatriz.setBounds(60, 23, 96, 45);
		lblOrdemDaMatriz.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblOrdemDaMatriz.setHorizontalTextPosition(SwingConstants.CENTER);
		lblOrdemDaMatriz.setHorizontalAlignment(SwingConstants.CENTER);

		JLabel lblMtodoDeSoluo = new JLabel("M\u00E9todo para c\u00E1lculo das integrais");
		lblMtodoDeSoluo.setBounds(21, 123, 263, 41);
		lblMtodoDeSoluo.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblMtodoDeSoluo.setHorizontalTextPosition(SwingConstants.CENTER);
		lblMtodoDeSoluo.setHorizontalAlignment(SwingConstants.LEFT);

		JRadioButton butquadgauss = new JRadioButton("Quadratura de Gauss");
		butquadgauss.setBounds(290, 128, 172, 30);
		butquadgauss.setFocusPainted(false);
		butquadgauss.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		butquadgauss.setActionCommand("");
		butquadgauss.setBackground(Color.LIGHT_GRAY);
		buttonGroup.add(butquadgauss);

		JRadioButton butquadpoli = new JRadioButton("Quadratura Polinomial");
		butquadpoli.setBounds(479, 128, 183, 31);
		butquadpoli.setFocusPainted(false);
		butquadpoli.setFont(new Font("Segoe UI", Font.PLAIN, 16));
		butquadpoli.setBackground(Color.LIGHT_GRAY);
		buttonGroup.add(butquadpoli);

		butquadpoli.addActionListener(iterativoActionListener);
		butquadgauss.addActionListener(decActionListener);

		JSeparator separator = new JSeparator();
		separator.setBounds(21, 97, 632, 2);
		separator.setForeground(Color.GRAY);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(165, 35, 65, 28);
		scrollPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);


		JPanel panel_1 = new JPanel();
		panel_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		panel_1.setBackground(new Color(192, 192, 192));
		tabbedPane.addTab("Dados de Sa\u00EDda", null, panel_1, null);

		JLabel lblCaminhoParaSaida = new JLabel("Caminho para arquivo de sa\u00EDda");
		lblCaminhoParaSaida.setBounds(10, 27, 258, 41);
		lblCaminhoParaSaida.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCaminhoParaSaida.setHorizontalAlignment(SwingConstants.LEFT);
		lblCaminhoParaSaida.setFont(new Font("Segoe UI", Font.BOLD, 17));

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(272, 37, 400, 23);
		scrollPane_2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_2.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(new Rectangle(243, 79, 70, 91));
		ImageIcon icon = (new ImageIcon(Tela_integral.class.getResource("/imagens/Minerva_UFRJ_Oficial.png")));
		Image img = icon.getImage();
		Image imgScale = img.getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(),Image.SCALE_SMOOTH);
		ImageIcon scaledIcon = new ImageIcon(imgScale);
		lblNewLabel.setIcon(scaledIcon);

		JLabel Labelolho = new JLabel("");
		Labelolho.setVerticalAlignment(SwingConstants.TOP);
		Labelolho.setBackground(Color.WHITE);
		Labelolho.setBounds(new Rectangle(352, 79, 70, 70));
		ImageIcon icone = (new ImageIcon(Tela_integral.class.getResource("/imagens/logo1.jpg")));
		Image imge = icone.getImage();
		Image imgScaled = imge.getScaledInstance(Labelolho.getWidth(), Labelolho.getHeight(),Image.SCALE_SMOOTH);
		ImageIcon scaledIcone = new ImageIcon(imgScaled);
		Labelolho.setIcon(scaledIcone);

		JButton butPronto = new JButton("Pronto");
		butPronto.setBounds(785, 55, 65, 23);

		JTextArea textpathsaida = new JTextArea();
		scrollPane_2.setViewportView(textpathsaida);
		textpathsaida.setDropMode(DropMode.INSERT);
		textpathsaida.setBorder(null);
		panel_1.setLayout(null);
		panel_1.add(lblCaminhoParaSaida);
		panel_1.add(lblNewLabel);
		panel_1.add(scrollPane_2);
		panel_1.add(butPronto);
		panel_1.add(Labelolho);
		
		JTextArea textointervalo = new JTextArea();
		scrollPane.setViewportView(textointervalo);
		textointervalo.setBorder(null);
		textointervalo.setWrapStyleWord(true);
		textointervalo.setMinimumSize(new Dimension(5, 20));
		textointervalo.setMaximumSize(new Dimension(5, 20));
		textointervalo.setColumns(1);
		textointervalo.setRows(1);


		textointervalo.setDropMode(DropMode.INSERT);
		panel.setLayout(null);
		panel.add(separator);
		panel.add(lblMtodoDeSoluo);
		panel.add(butquadgauss);
		panel.add(butquadpoli);
		panel.add(lblOrdemDaMatriz);
		panel.add(scrollPane);
		
		JLabel lblNmeroDe = new JLabel("N\u00FAmero de pontos de integra\u00E7\u00E3o [2,10]");
		lblNmeroDe.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNmeroDe.setHorizontalAlignment(SwingConstants.CENTER);
		lblNmeroDe.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNmeroDe.setEnabled(true);
		lblNmeroDe.setBounds(285, 23, 278, 45);
		panel.add(lblNmeroDe);
		
		JScrollPane scrollPane_texttol_1 = new JScrollPane();
		scrollPane_texttol_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_texttol_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_texttol_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane_texttol_1.setBounds(573, 35, 89, 27);
		panel.add(scrollPane_texttol_1);
		
		JTextArea textonumeropontos = new JTextArea();
		textonumeropontos.setEnabled(true);
		textonumeropontos.setDropMode(DropMode.INSERT);
		textonumeropontos.setBorder(null);
		scrollPane_texttol_1.setViewportView(textonumeropontos);


		ActionListener determinanteActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener determinante_2ActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton  butgauss= (AbstractButton) actionEvent.getSource();
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
			}
		};
		butquadpoli.addActionListener(determinante_2ActionListener);
		butquadgauss.addActionListener(determinanteActionListener);


		JButton butpronto = new JButton("Pronto");
		butpronto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (butquadgauss.isSelected()) {
					try {
						calc(textpathsaida.getText(), textointervalo.getText(), textonumeropontos.getText(), "quadgauss"  );
					} catch (Exception e1) {
						e1.printStackTrace();}
				}
				if (butquadpoli.isSelected()) {
					try {
						calc(textpathsaida.getText(), textointervalo.getText(), textonumeropontos.getText(), "quadpoli"  );
					} catch (Exception e1) {
						e1.printStackTrace();}
				}
			}
		});
		butpronto.setFocusable(false);
		butpronto.setFont(new Font("Tahoma", Font.PLAIN, 12));
		butpronto.setBounds(587, 134, 89, 23);
		panel_1.add(butpronto);

	}
}

