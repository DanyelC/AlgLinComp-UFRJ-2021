package telas;
import  mat.MatFunc;
import mat.Resposta;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.AbstractButton;
import javax.swing.DropMode;
import javax.swing.ButtonGroup;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import java.awt.Canvas;
import java.awt.ScrollPane;
import javax.swing.Box;
import java.awt.Panel;
import javax.swing.JInternalFrame;
import javax.swing.JTextField;

public class Tela_principal extends JFrame {
	public double [] consts= {1,2,3,4};
	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private static JTextField textoconst;
	//private JFrame secondFrame = new JFrame("My 2nd Window!");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela_principal frame = new Tela_principal();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static double[] constantes() throws IOException {
		String constantes = textoconst.getText();
		String[] parts = constantes.split(",");
		double[] consts=new double[4];
		for(int i = 0; i < 4; i++ ) {
			consts[i]=Double.parseDouble(parts[i]);
		}
		return consts;
	}
	
	public static void calc(String caminhosaida , String npontos_string, String tolmax_string, String metodo) throws IOException {
		int size=0;
		double [] pontos = new double[3];
		/*try{
			size = Integer.parseInt(npontos_string);
			if(size==1) {
				JOptionPane.showMessageDialog(null,"ERRO! - S�o necess�rios dois pontos para realizar o c�lculo.");
				return;
			}
		}catch (Exception e) {
			//JOptionPane.showMessageDialog(null,"ERRO! - A entrada 'n�mero de pontos' deve ser um n�mero inteiro.");
			return;
		}*/
		String[] parts = npontos_string.split(",");
		for(int i = 0; i < 2; i++ ) {
			pontos[i]=Double.parseDouble(parts[i]);
			//System.out.printf("%.2f ", pontos[i]);
		}

	}


	/**
	 * Create the frame.
	 */
	public Tela_principal() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Tela_principal.class.getResource("/imagens/logo1.jpg")));
		setTitle("Resolu\u00E7\u00E3o de Sistemas N\u00E3o Lineares");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 625, 330); // tamanho da tela

		JFileChooser openFileChooser;
		openFileChooser = new JFileChooser();
		openFileChooser.setCurrentDirectory(new File ("c:\\temp"));
		openFileChooser.setFileFilter(new FileNameExtensionFilter("arquivos em texto","txt"));

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnAjuda = new JMenu("Ajuda");
		menuBar.add(mnAjuda);

		JMenuItem mntmManualDeInstrues = new JMenuItem("Manual de Instru\u00E7\u00F5es");
		mntmManualDeInstrues.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Tela_ajuda telaajuda = new Tela_ajuda();
				telaajuda.setVisible(true);
			}
		});
		mntmManualDeInstrues.setHorizontalAlignment(SwingConstants.CENTER);
		mnAjuda.add(mntmManualDeInstrues);

		JMenu mnSobre = new JMenu("Sobre");
		menuBar.add(mnSobre);

		JMenuItem mntmSobreOPrograma = new JMenuItem("Sobre o programa");
		mntmSobreOPrograma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tela_sobre telasobre = new Tela_sobre();
				telasobre.setVisible(true);
			}
		});
		mntmSobreOPrograma.setHorizontalAlignment(SwingConstants.CENTER);
		mnSobre.add(mntmSobreOPrograma);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.LIGHT_GRAY);
		contentPane.add(tabbedPane, BorderLayout.CENTER);


		ActionListener iterativoActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener decActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};
		

		JPanel panel = new JPanel();
		panel.setRequestFocusEnabled(false);
		panel.setFocusable(false);
		panel.setFocusTraversalKeysEnabled(false);
		panel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		panel.setBackground(Color.LIGHT_GRAY);
		tabbedPane.addTab("Escolha da opera��o", null, panel, null);
		ImageIcon icon = (new ImageIcon(Tela_principal.class.getResource("/imagens/Minerva_UFRJ_Oficial.png")));
		Image img = icon.getImage();
		
		//ImageIcon scaledIcon = new ImageIcon(imgScale);
		ImageIcon icone = (new ImageIcon(Tela_principal.class.getResource("/imagens/logo1.jpg")));
		Image imge = icone.getImage();
		//ImageIcon scaledIcone = new ImageIcon(imgScaled);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(74, 33, 439, 2);
		separator_1.setForeground(Color.GRAY);
		panel.setLayout(null);
		panel.add(separator_1);
		
		JLabel lblDerivadaDf = new JLabel("Derivada DF");
		lblDerivadaDf.setHorizontalTextPosition(SwingConstants.CENTER);
		lblDerivadaDf.setHorizontalAlignment(SwingConstants.CENTER);
		lblDerivadaDf.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblDerivadaDf.setEnabled(true);
		lblDerivadaDf.setBounds(26, 160, 100, 30);
		panel.add(lblDerivadaDf);
		
		JLabel lblDerivada = new JLabel("Derivada RE");
		lblDerivada.setHorizontalTextPosition(SwingConstants.CENTER);
		lblDerivada.setHorizontalAlignment(SwingConstants.CENTER);
		lblDerivada.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblDerivada.setEnabled(true);
		lblDerivada.setBounds(328, 160, 92, 30);
		panel.add(lblDerivada);
		
		JLabel lblNewLabel_1 = new JLabel("C\u00E1lculo da Raiz");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblNewLabel_1.setBounds(13, 98, 126, 22);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Selecione a tarefa a ser realizada:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.BOLD, 17));
		lblNewLabel_1_1.setBounds(149, 11, 300, 22);
		panel.add(lblNewLabel_1_1);
		
		JButton butgoraiz = new JButton("Selecionar");
		butgoraiz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tela_raiz telaraiz = new Tela_raiz();
				telaraiz.setVisible(true);
			}
		});
		butgoraiz.setFocusable(false);
		butgoraiz.setBounds(149, 101, 100, 23);
		panel.add(butgoraiz);
		
		JButton butgodf = new JButton("Selecionar");
		butgodf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tela_derivada_df teladerivadadf = new Tela_derivada_df();
				teladerivadadf.setVisible(true);
			}
		});
		butgodf.setFocusable(false);
		butgodf.setBounds(149, 167, 100, 23);
		panel.add(butgodf);
		
		JButton butgoint = new JButton("Selecionar");
		butgoint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tela_integral telaintegral = new Tela_integral();
				telaintegral.setVisible(true);
			}
		});
		butgoint.setFocusable(false);
		butgoint.setBounds(463, 101, 100, 23);
		panel.add(butgoint);
		
		JButton butgore = new JButton("Selecionar");
		butgore.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tela_derivada_re teladerivadare = new Tela_derivada_re();
				teladerivadare.setVisible(true);
			}
		});
		butgore.setFocusable(false);
		butgore.setBounds(463, 167, 100, 23);
		panel.add(butgore);
		
		JLabel lblNewLabel_1_2 = new JLabel("C\u00E1lculo da Integral");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblNewLabel_1_2.setBounds(303, 98, 144, 22);
		panel.add(lblNewLabel_1_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(222, 56, 159, 22);
		panel.add(scrollPane);
		
		textoconst = new JTextField();
		textoconst.setBorder(null);
		scrollPane.setViewportView(textoconst);
		textoconst.setColumns(10);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Constantes c1, c2, c3 e c4:");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblNewLabel_1_1_1.setBounds(13, 56, 199, 22);
		panel.add(lblNewLabel_1_1_1);


		ActionListener determinanteActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener determinante_2ActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton  butgauss= (AbstractButton) actionEvent.getSource();
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
			}
		};


	}
}
