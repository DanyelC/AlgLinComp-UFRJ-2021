package telas;
import  mat.MatFunc;
import mat.Resposta;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.AbstractButton;
import javax.swing.DropMode;
import javax.swing.ButtonGroup;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import javax.swing.JTextField;

public class Tela_derivada_re extends JFrame {
	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private JTextField textodeltax1;
	private JTextField textodeltax2;
	private JTextField textpathsaida;
	private JTextField textoponto;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela_derivada_re frame = new Tela_derivada_re();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void calc(String caminhosaida , String ponto_string, String deltax1_string, String deltax2_string) throws Exception {
		double[] consts = Tela_principal.constantes();
		double deltax1=0;
		double deltax2=0;
		double ponto=0;
		try{
			deltax1 = Double.parseDouble(deltax1_string);
			deltax2 = Double.parseDouble(deltax2_string);
			ponto = Double.parseDouble(ponto_string);
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null,"ERRO! - Revise as vari�veis de entrada.");
			return;
		}

		FileWriter arquivo_saida = new FileWriter(caminhosaida);
		PrintWriter escritor = new PrintWriter(arquivo_saida);

		escritor.print("Valor delta_x1 lido : ");
		escritor.printf("%.3f", deltax1);
		escritor.println();
		escritor.print("Valor delta_x2 lido : ");
		escritor.printf("%.3f", deltax2);
		escritor.println();

		double resp = MatFunc.richard_ext(consts, ponto, deltax1, deltax2);  // VER ISSO
		escritor.println("Usando a extrapola��o de Richard");
		escritor.printf("Valor encontrado: %.3f", resp);
		arquivo_saida.close();
		JOptionPane.showMessageDialog(null,"Arquivo gerado com sucesso em: "+caminhosaida);

	}


	/**
	 * Create the frame.
	 */
	public Tela_derivada_re() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Tela_derivada_re.class.getResource("/imagens/logo1.jpg")));
		setTitle("C\u00E1lculo de derivadas");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 722, 300); // tamanho da tela

		JFileChooser openFileChooser;
		openFileChooser = new JFileChooser();
		openFileChooser.setCurrentDirectory(new File ("c:\\temp"));
		openFileChooser.setFileFilter(new FileNameExtensionFilter("arquivos em texto","txt"));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.LIGHT_GRAY);
		contentPane.add(tabbedPane, BorderLayout.CENTER);


		ActionListener iterativoActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener decActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};


		JPanel panel_1 = new JPanel();
		panel_1.setFocusTraversalKeysEnabled(false);
		panel_1.setFocusable(false);
		panel_1.setRequestFocusEnabled(false);
		panel_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		panel_1.setBackground(new Color(128, 128, 128));
		tabbedPane.addTab("Dados de Entrada", null, panel_1, null);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBackground(new Color(128, 128, 128));
		lblNewLabel.setBounds(new Rectangle(244, 123, 70, 91));
		ImageIcon icon = (new ImageIcon(Tela_derivada_re.class.getResource("/imagens/minerva_semfundo.png")));
		Image img = icon.getImage();
		Image imgScale = img.getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(),Image.SCALE_SMOOTH);
		ImageIcon scaledIcon = new ImageIcon(imgScale);
		lblNewLabel.setIcon(scaledIcon);

		JLabel Labelolho = new JLabel("");
		Labelolho.setVerticalAlignment(SwingConstants.TOP);
		Labelolho.setBackground(Color.WHITE);
		Labelolho.setBounds(new Rectangle(353, 131, 70, 70));
		ImageIcon icone = (new ImageIcon(Tela_derivada_re.class.getResource("/imagens/logo1.jpg")));
		Image imge = icone.getImage();
		Image imgScaled = imge.getScaledInstance(Labelolho.getWidth(), Labelolho.getHeight(),Image.SCALE_SMOOTH);
		ImageIcon scaledIcone = new ImageIcon(imgScaled);
		Labelolho.setIcon(scaledIcone);

		JButton butPronto = new JButton("Pronto");
		butPronto.setBounds(785, 55, 65, 23);
		panel_1.setLayout(null);
		panel_1.add(lblNewLabel);
		panel_1.add(butPronto);
		panel_1.add(Labelolho);

		JLabel lblOrdemDaMatriz = new JLabel("Valor de delta_x1");
		lblOrdemDaMatriz.setHorizontalTextPosition(SwingConstants.CENTER);
		lblOrdemDaMatriz.setHorizontalAlignment(SwingConstants.CENTER);
		lblOrdemDaMatriz.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblOrdemDaMatriz.setBounds(191, 11, 121, 45);
		panel_1.add(lblOrdemDaMatriz);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setBounds(320, 23, 86, 28);
		panel_1.add(scrollPane);

		textodeltax1 = new JTextField();
		textodeltax1.setBorder(null);
		scrollPane.setViewportView(textodeltax1);
		textodeltax1.setColumns(10);

		JLabel lblNmeroDe = new JLabel("Valor de delta_x2");
		lblNmeroDe.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNmeroDe.setHorizontalAlignment(SwingConstants.CENTER);
		lblNmeroDe.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblNmeroDe.setEnabled(true);
		lblNmeroDe.setBounds(441, 11, 137, 45);
		panel_1.add(lblNmeroDe);

		JScrollPane scrollPane_texttol_1 = new JScrollPane();
		scrollPane_texttol_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_texttol_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_texttol_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane_texttol_1.setBounds(583, 23, 89, 27);
		panel_1.add(scrollPane_texttol_1);

		textodeltax2 = new JTextField();
		textodeltax2.setColumns(10);
		textodeltax2.setBorder(null);
		scrollPane_texttol_1.setViewportView(textodeltax2);

		JLabel lblCaminhoParaSaida = new JLabel("Caminho para arquivo de sa\u00EDda");
		lblCaminhoParaSaida.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCaminhoParaSaida.setHorizontalAlignment(SwingConstants.LEFT);
		lblCaminhoParaSaida.setFont(new Font("Segoe UI", Font.BOLD, 17));
		lblCaminhoParaSaida.setBounds(10, 79, 258, 41);
		panel_1.add(lblCaminhoParaSaida);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_2.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane_2.setBounds(272, 89, 400, 23);
		panel_1.add(scrollPane_2);

		textpathsaida = new JTextField();
		textpathsaida.setBorder(null);
		scrollPane_2.setViewportView(textpathsaida);
		textpathsaida.setColumns(10);

		JSeparator separator = new JSeparator();
		separator.setBounds(10, 67, 662, 2);
		panel_1.add(separator);




		ActionListener determinanteActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener determinante_2ActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton  butgauss= (AbstractButton) actionEvent.getSource();
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
			}
		};


		JButton butpronto = new JButton("Pronto");
		butpronto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					calc(textpathsaida.getText(), textoponto.getText(),textodeltax1.getText(),textodeltax2.getText());
				} catch (Exception e1) {
					e1.printStackTrace();}
			}
		});
		butpronto.setFocusable(false);
		butpronto.setFont(new Font("Tahoma", Font.PLAIN, 12));
		butpronto.setBounds(583, 191, 89, 23);
		panel_1.add(butpronto);
		
		JLabel lblPonto = new JLabel("Ponto");
		lblPonto.setHorizontalTextPosition(SwingConstants.CENTER);
		lblPonto.setHorizontalAlignment(SwingConstants.CENTER);
		lblPonto.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblPonto.setBounds(10, 11, 56, 45);
		panel_1.add(lblPonto);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane_1.setBounds(65, 23, 86, 28);
		panel_1.add(scrollPane_1);
		
		textoponto = new JTextField();
		textoponto.setColumns(10);
		textoponto.setBorder(null);
		scrollPane_1.setViewportView(textoponto);

	}
}

