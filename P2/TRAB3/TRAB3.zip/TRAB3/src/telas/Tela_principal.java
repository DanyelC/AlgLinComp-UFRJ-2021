package telas;
import  mat.MatFunc;
import mat.Resposta;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.AbstractButton;
import javax.swing.DropMode;
import javax.swing.ButtonGroup;
import javax.swing.JSeparator;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.Dimension;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import java.awt.Rectangle;
import java.awt.SystemColor;

public class Tela_principal extends JFrame {
	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela_principal frame = new Tela_principal();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void calc(String caminhosaida , String parametros_string, String tempo_string, String passo_string) throws Exception {
		int size=0;
		double [] pontos = new double[9];

		String[] parts = parametros_string.split(",");
		for(int i = 0; i < 2; i++ ) {
			pontos[i]=Double.parseDouble(parts[i]);
			//System.out.printf("%.2f ", pontos[i]);
		}

		double T = Double.parseDouble(tempo_string);
		double h = Double.parseDouble(tempo_string);
		double m=pontos[0];
		double c=pontos[1];
		double k=pontos[2];
		double[] a = new double [3];
		double[] w = new double [3];
		for(int i = 3; i< 6; i++) {
			a[i-3]=pontos[i];
		}
		for(int i = 6; i< 9; i++) {
			a[i-6]=pontos[i];
		}


		FileWriter arquivo_saida = new FileWriter(caminhosaida);
		PrintWriter escritor = new PrintWriter(arquivo_saida);

		escritor.print("Intervalo lido [a, b] : ");
		escritor.printf("(%.2f, %.2f)", pontos[0],pontos[1]);
		escritor.println();
		double x = 0;
		double v =0;
		//escritor.close(); 

		Resposta resp = MatFunc.range(h,T,x,v,a,w,m,c,k); // VER ISSO
		escritor.printf("Passo estabelecido: %f\n",h);
		escritor.println("M�todo de Runge-Kutta-Nystron.");
		escritor.printf("Tempo, posi��o, velocidade e acelera��o: %.3f, %.3f, %.3f, %.3f", resp.t, resp.x, resp.v, resp.acel);
		arquivo_saida.close();
		JOptionPane.showMessageDialog(null,"Arquivo gerado com sucesso em: "+caminhosaida);

	}


	/**
	 * Create the frame.
	 */
	public Tela_principal() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Tela_principal.class.getResource("/imagens/logo1.jpg")));
		setTitle("Runge-Kutta-Nystron");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 722, 274); // tamanho da tela

		JFileChooser openFileChooser;
		openFileChooser = new JFileChooser();
		openFileChooser.setCurrentDirectory(new File ("c:\\temp"));
		openFileChooser.setFileFilter(new FileNameExtensionFilter("arquivos em texto","txt"));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.LIGHT_GRAY);
		contentPane.add(tabbedPane, BorderLayout.CENTER);


		JLabel tolmax = new JLabel("Tempo total de integra\u00E7\u00E3o");
		tolmax.setBounds(48, 54, 202, 45);
		tolmax.setEnabled(true);
		tolmax.setHorizontalTextPosition(SwingConstants.CENTER);
		tolmax.setHorizontalAlignment(SwingConstants.CENTER);
		tolmax.setFont(new Font("Segoe UI", Font.BOLD, 16));

		JScrollPane scrollPane_texttol = new JScrollPane();
		scrollPane_texttol.setBounds(260, 66, 89, 27);
		scrollPane_texttol.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_texttol.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_texttol.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));


		JTextArea textotempo = new JTextArea();
		scrollPane_texttol.setViewportView(textotempo);
		textotempo.setBorder(null);
		textotempo.setEnabled(true);
		textotempo.setDropMode(DropMode.INSERT);


		ActionListener iterativoActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener decActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};


		JPanel panel = new JPanel();
		panel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		panel.setBackground(new Color(211, 211, 211));
		tabbedPane.addTab("Dados da aplica��o", null, panel, null);

		JLabel lblOrdemDaMatriz = new JLabel("Passo");
		lblOrdemDaMatriz.setBounds(409, 54, 58, 45);
		lblOrdemDaMatriz.setFont(new Font("Segoe UI", Font.BOLD, 16));
		lblOrdemDaMatriz.setHorizontalTextPosition(SwingConstants.CENTER);
		lblOrdemDaMatriz.setHorizontalAlignment(SwingConstants.CENTER);

		JSeparator separator = new JSeparator();
		separator.setBounds(21, 110, 632, 2);
		separator.setForeground(Color.GRAY);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(471, 66, 65, 28);
		scrollPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		ImageIcon icon = (new ImageIcon(Tela_principal.class.getResource("/imagens/Minerva_UFRJ_Oficial.png")));
		Image img = icon.getImage();
		//ImageIcon scaledIcon = new ImageIcon(imgScale);
		ImageIcon icone = (new ImageIcon(Tela_principal.class.getResource("/imagens/logo1.jpg")));
		Image imge = icone.getImage();
		//ImageIcon scaledIcone = new ImageIcon(imgScaled);

		JTextArea textopasso = new JTextArea();
		scrollPane.setViewportView(textopasso);
		textopasso.setBorder(null);
		textopasso.setWrapStyleWord(true);
		textopasso.setMinimumSize(new Dimension(5, 20));
		textopasso.setMaximumSize(new Dimension(5, 20));
		textopasso.setColumns(1);
		textopasso.setRows(1);

		textopasso.setDropMode(DropMode.INSERT);
		panel.setLayout(null);
		panel.add(separator);
		panel.add(lblOrdemDaMatriz);
		panel.add(scrollPane);
		panel.add(tolmax);
		panel.add(scrollPane_texttol);

		JLabel lblOrdemDaMatriz_1 = new JLabel("Par\u00E2metros m,c,k, a1, a2, a3, w1, w2, w3");
		lblOrdemDaMatriz_1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblOrdemDaMatriz_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblOrdemDaMatriz_1.setFont(new Font("Segoe UI", Font.BOLD, 15));
		lblOrdemDaMatriz_1.setBounds(100, 11, 290, 45);
		panel.add(lblOrdemDaMatriz_1);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane_1.setBounds(399, 23, 154, 24);
		panel.add(scrollPane_1);

		JTextArea textoparametros = new JTextArea();
		textoparametros.setWrapStyleWord(true);
		textoparametros.setRows(1);
		textoparametros.setMinimumSize(new Dimension(5, 20));
		textoparametros.setMaximumSize(new Dimension(5, 20));
		textoparametros.setDropMode(DropMode.INSERT);
		textoparametros.setColumns(1);
		textoparametros.setBorder(null);
		scrollPane_1.setViewportView(textoparametros);

		JLabel lblCaminhoParaSaida = new JLabel("Caminho para arquivo de sa\u00EDda");
		lblCaminhoParaSaida.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCaminhoParaSaida.setHorizontalAlignment(SwingConstants.LEFT);
		lblCaminhoParaSaida.setFont(new Font("Segoe UI", Font.BOLD, 17));
		lblCaminhoParaSaida.setBounds(10, 123, 258, 41);
		panel.add(lblCaminhoParaSaida);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_2.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane_2.setBounds(272, 133, 382, 23);
		panel.add(scrollPane_2);

		JTextArea textopathsaida = new JTextArea();
		textopathsaida.setWrapStyleWord(true);
		textopathsaida.setRows(1);
		textopathsaida.setMinimumSize(new Dimension(5, 20));
		textopathsaida.setMaximumSize(new Dimension(5, 20));
		textopathsaida.setDropMode(DropMode.INSERT);
		textopathsaida.setColumns(1);
		textopathsaida.setBorder(null);
		scrollPane_2.setViewportView(textopathsaida);

		JButton btnNewButton = new JButton("Pronto");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					calc(textopathsaida.getText(), textoparametros.getText(),textotempo.getText(), textopasso.getText());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(306, 173, 89, 23);
		panel.add(btnNewButton);

		//



		ActionListener determinanteActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton butpot = (AbstractButton) actionEvent.getSource();
			}
		};

		ActionListener determinante_2ActionListener = new ActionListener() {
			public void actionPerformed(ActionEvent actionEvent) {
				AbstractButton  butgauss= (AbstractButton) actionEvent.getSource();
				AbstractButton butjacobi = (AbstractButton) actionEvent.getSource();
			}
		};


		/*butPronto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (butbis.isSelected()) {
					try {
						calc(textpathentrada.getText(), textpathsaida.getText(), textointervalo.getText(), "determinante", texttolmax.getText(), "pot"  );
					} catch (IOException e1) {
						e1.printStackTrace();}
				}
				if (butnewton.isSelected()) {
					try {
						calc(textpathentrada.getText(), textpathsaida.getText(), textointervalo.getText(),  "determinante", texttolmax.getText(), "jacobi"  );
					} catch (IOException e1) {
						e1.printStackTrace();}
				}

			}
		});*/

	}
}

