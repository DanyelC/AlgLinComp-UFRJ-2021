package mat;
import java.util.*;
import javax.swing.JOptionPane;

/**
 * Classe criada com o intuito de lidar com os c�lculos necess�rios no programa
 * @author Danyel Clin�rio dos Santos
 * @email danyel.clinario@poli.ufrj.br
 */

public class MatFunc {

	public static double func(double t, double[] a, double[] w) {
		return a[0] * Math.sin(w[0] * t) + a[1] * Math.sin(w[1] * t) + a[2] * Math.sin(w[2] * t);
	}

	public static double ed(double t, double y, double yderivado, double c, double k, double m, double[] a, double[] w) {
		return (func(t, a, w) - c * yderivado - k * y) / m;
	}

	public static Resposta range (double h , double T , double x , double v , double[] a , double[] w , double m , double c , double k ) {
		//double h , double T , double x , double v , double[] a , double[] w , double m , double c , double k
		//double h = 0.1; double T = 250; double x = 0; double v = 0;  double m = 1; double c = 0.1;  double k = 2;
		/*double[] a= new double[3];
		double[] w= new double[3];
		a[0]= 1;
		a[1]=2;
		a[2] = 1.5;
		w[0]= 0.05;
		w[1]=1;
		w[2] = 2;*/
		x=0;
		v=0;
		double n = T / h;
		double tprevious = 0;
		//double[][] results =new double[3][1];
		double aceleration=0;
		double t =0 ;
		Resposta results = new Resposta();
		for (double i=1; i<n+1; i++) {
			t = i * h;
			double k1 = (h / 2) * ed(tprevious, x, v, c, k, m, a, w);
			double K = (h / 2) * (v + k1 / 2);
			double k2 = (h / 2) * ed(tprevious + (h / 2), x + K, v + k1, c, k, m, a, w);
			double k3 = (h / 2) * ed(tprevious + (h / 2), x + K, v + k2, c, k, m, a, w);
			double L = h * (v + k3);
			double k4 = (h / 2) * ed(tprevious + h, x + L, v + 2 * k3, c, k, m, a, w);
			x = x + h * (v + (1 / 3) * (k1 + k2 + k3));
			v = v + (1 / 3)  * (k1 + 2 * k2 + 2 * k3 + k4);
			tprevious = t;
			aceleration = ed(t, x, v, c, k, m, a, w);

		}
		results.t=t;
		results.x=x;
		results.v=v;
		results.acel=aceleration;

		return results;
	}

	public static double runge(int n, double[] x, double[] y,double xpy) {

		double soma_x = 0 , soma_y=0 , soma_xy=0 , soma_x2 = 0;
		for (int i = 0; i < n; i++) { 
			soma_x += x[i];
			soma_y += y[i];
			soma_xy += x[i]*y[i];
			soma_x2 += Math.pow(x[i],2);
		}
		double alfa = (n*soma_xy - soma_x*soma_y)/(n*soma_x2 - Math.pow(soma_x,2));
		double beta = soma_y/n - alfa*soma_x/n;
		double resp = alfa*xpy + beta;
		System.out.println(resp);
		return resp;
	}
}

